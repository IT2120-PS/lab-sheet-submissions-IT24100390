setwd("C:\\Users\\thava\\OneDrive\\Documents\\Sliit semester 3\\PS\\lab 8")
getwd()
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

p_mean<-mean(Weight.kg.)
p_mean
p_sd<-sd(Weight.kg.)
p_sd

samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}
colnames(samples)=n
samples
n

s_means<-apply(samples,2,mean)
s_means
s_sds<-apply(samples,2,sd)
s_sds
#2 = operate column-wise (1 would be row-wise)

samplemean<-mean(s_means)
samplemean
sample_sd<-sd(s_sds)
sample_sd

s_means
samplemean

true_sd=sample_sd/sqrt(2)
true_sd

