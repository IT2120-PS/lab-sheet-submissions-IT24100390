
setwd("C:/Users/thava/OneDrive/Desktop/IT24100390")
getwd()
shareholders_data <- read.csv("Data.txt")
shareholders <- shareholders_data$Number_of_Shareholders.thousands.

# 1. Basic Histogram
hist(shareholders,
     main = "Histogram of Shareholders",
     xlab = "Number of Shareholders (in thousands)",
     col = "skyblue",
     border = "white")

# 2. Histogram with 7 classes (130 to 270)
breaks_shareholders <- seq(130, 270, length.out = 8)
hist(shareholders,
     breaks = breaks_shareholders,
     right = FALSE,
     main = "Histogram with 7 Classes",
     xlab = "Shareholders",
     col = "lightgreen",
     border = "white")

# 3. Frequency Distribution
freq_table <- table(cut(shareholders, breaks = breaks_shareholders, right = FALSE))
print(freq_table)

# 4. Frequency Polygon
midpoints <- (head(breaks_shareholders, -1) + tail(breaks_shareholders, -1)) / 2
plot(midpoints, as.numeric(freq_table),
     type = "o",
     col = "blue",
     xlab = "Midpoints",
     ylab = "Frequency",
     main = "Frequency Polygon")

# 5. Ogive (Cumulative Frequency Polygon)
cum_freq <- cumsum(as.numeric(freq_table))
plot(breaks_shareholders[-1], cum_freq,
     type = "o",
     col = "red",
     xlab = "Upper Class Boundaries",
     ylab = "Cumulative Frequency",
     main = "Ogive for Shareholders")


